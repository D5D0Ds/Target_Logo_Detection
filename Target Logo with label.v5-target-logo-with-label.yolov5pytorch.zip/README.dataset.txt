# Target Logo with label > Target Logo with Label
https://universe.roboflow.com/object-detection/target-logo-with-label

Provided by Roboflow
License: MIT

